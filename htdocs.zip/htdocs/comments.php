<?php

$newcomment = $_REQUEST['newcomment'];
$name = $_REQUEST['name'];
$addTo = $_REQUEST['addTo'];

$song = $_REQUEST['song'];

if (!empty($song)) {
    $fname = 'music/' . $song . '/comments.json';
    $content = file($fname);

    foreach ($content as $val) {
        $arr = json_decode($val, true);

        $name = $arr['name'];
        $comment = $arr['comment'];

        echo "<div class='comment'>
<div class='usr0'>
    <div class='usr'></div>
                    @$name
</div>
<div class='comment_txt'>
    <div>
       $comment
     </div>
</div></div>";

    }

}

if (!empty($newcomment)) {

    $added = '{"name" : "' . $name . '", "comment" : "' . $newcomment . '"}';

    $fname = 'music/' . $addTo . '/comments.json';
    $content = file($fname);

    array_push($content, $added);

    $fp = fopen($fname, "w");
    fputs($fp, implode($content) . PHP_EOL);
    fclose($fp);

    foreach ($content as $val) {
        $arr = json_decode($val, true);

        $name = $arr['name'];
        $comment = $arr['comment'];

        echo "<div class='comment'>
<div class='usr0'>
    <div class='usr'></div>
                    @$name
</div>
<div class='comment_txt'>
    <div>
       $comment
     </div>
</div></div>";

    }
}





function pre_r($arr) {
    echo("<pre>");
    print_r($arr);
    echo("</pre>");
}

?>