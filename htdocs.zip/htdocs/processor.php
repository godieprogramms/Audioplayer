<?php

$songs = scandir("music");

$array = array();
array_splice($songs, 0, 2, $array);

foreach ($songs as $val) {
    $file = 'music/'.$val .'/songinfo.txt';
    $content = file($file);

    $arr = explode("||", $content[0]);

    $Artist = $arr[0];
    $songname = $arr[1];
    $desc = $arr[2];


    echo "<div class='song' onclick='play($val)'>
    <div id='art'><img class='art' src='music/$val/$val.png'></div>
    <span class='songname'>$Artist - $songname</span>
   </div>";

}


function pre_r($arr) {
    echo("<pre>");
    print_r($arr);
    echo("</pre>");
}
?>