<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Music Tune</title>
    <link rel="stylesheet" href="style.css">
    <script src="jquery.js"></script>
</head>
<body>

    <div class="player_container"></div>

    <div class="songlist_container"></div>

    <audio class="audio" src=""></audio>

    <div class="comment_box">
        <div class="comment_list"></div>

        <div class="write">
            <input type='text' id='clear' class="input" placeholder="write your comments here!"></input>
            <button class='send_comments'>Send</button>
        </div>
    </div>






    <script src="main.js"></script>
    <script>
        $(".songlist_container").load("processor.php");


        function play(val) {
            $(".audio").attr('src', 'music/'+val+'/'+val+'.mp3');
            document.querySelector('.audio').play();
            
            $('.player_container').load('songIoader.php', {
                'song': val,
            });
            
            $('.comment_list').load('comments.php', {
                "song" : val,
            });
            
            window.x = val;
            
            vote(1);
            
            
            $('.songlist_container').animate({
                'margin-top' : '230px'
            })
        }

        function addcomment() {
            $('.comment_box').slideToggle();
            $('.comment_list').slideToggle();
        }
        
        $('.send_comments').click(function() {
            var input = document.querySelector('.input').value;
            $('.comment_list').load('comments.php', {
                "name" : "Nilcon",
                "newcomment" : input,
                "addTo" : x
            })
            
            $('.player_container').load('songIoader.php', {
                'song': x,
            });
            
            document.getElementById('clear').value = '';
        })
        
        
        function vote(num) {
            $('.song_info').load('insight.php', {
                'song' : x,
                "vote" : num
            });
        }
        





    </script>
</body>
</html>