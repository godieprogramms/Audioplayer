<?php

$song = $_REQUEST['song'];
$vote = $_REQUEST['vote'];

$file = 'music/' . $song . '/insights.txt';
$content = file($file);

$array = explode("||", $content[0]);
$views = $array[0];
$like = $array[1];
$dislike = $array[2];

if ($vote == 1) {
    $views = $views + 1;

}

if($vote == 2) {
    $like = $like + 1;
}

if($vote == 3) {
    $dislike = $dislike + 1;
}


$inst = $views.'||'.$like.'||'.$dislike;
$fp = fopen($file, "w");
fputs($fp, $inst);
fclose($fp);


$commentfile = 'music/' . $song . '/comments.json';
$cont = file($commentfile);

$commentcount = count($cont);


if ($views < 1e3) {
    $views = $views;
}

if ($views > 999 && $views < 1e6) {
    $views = round(($views / 1e3), 1) . 'K';
}

if ($views > 999999 && $views < 1e9) {
    $views = round(($views / 1e6), 1) . 'M';
}

if ($views >= 1e9) {
    $views = round(($views / 1e9), 1) . 'B';
}


if ($like < 1e3) {
    $like = $like;
}

if ($like > 999 && $like < 1e6) {
    $like = round(($like / 1e3), 1) . 'K';
}

if ($like > 999999 && $like < 1e9) {
    $like = round(($like / 1e6), 1) . 'M';
}

if ($like >= 1e9) {
    $like = round(($like / 1e9), 1) . 'B';
}



if ($dislike < 1e3) {
    $dislike = $dislike;
}

if ($dislike > 999 && $dislike < 1e6) {
    $dislike = round(($dislike / 1e3), 1) . 'K';
}

if ($dislike > 999999 && $dislike < 1e9) {
    $dislike = round(($dislike / 1e6), 1) . 'M';
}

if ($dislike >= 1e9) {
    $dislike = round(($dislike / 1e9), 1) . 'B';
}





echo "

<div class=''>
    <div class='views_count'>$views</div>
    <div>views</div>
</div>
<div class='' onclick='vote(2)'>
    <div>$like</div>
    <div>Like</div>
</div>
<div class='' onclick='vote(3)'>
    <div>$dislike</div>
    <div>Dislike</div>
</div>
<div class='' onclick='addcomment()'>
    <div>$commentcount</div>
    <div>comments</div>
</div>

";





?>